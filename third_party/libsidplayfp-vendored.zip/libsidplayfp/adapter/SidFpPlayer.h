/*
 * SidFpPlayer - a tiny, Qt-free PCM source that renders a SID tune through
 * libsidplayfp's bundled SIDLite chip. The app wraps this with a QAudioSink to
 * play the *original* SID authentically (alongside editing the converted MIDI).
 * No libsidplayfp internals leak through this header (plain std types only).
 */
#ifndef SIDFP_PLAYER_H
#define SIDFP_PLAYER_H

#include <cstddef>
#include <cstdint>
#include <string>

namespace sidfp {

class Renderer {
public:
    Renderer();
    ~Renderer();
    Renderer(const Renderer &) = delete;
    Renderer &operator=(const Renderer &) = delete;

    /**
     * Load @p data (one-file SID image, @p len bytes), select @p song (1-based,
     * 0 = default) and prepare mono rendering at @p sampleRate Hz.
     * @return true on success; otherwise error() explains why.
     */
    bool open(const uint8_t *data, std::size_t len, int song, int sampleRate);

    /**
     * Render up to @p maxSamples mono 16-bit samples into @p out.
     * @return the number of samples written (0 on error/empty).
     */
    int render(short *out, int maxSamples);

    bool        isOpen() const;
    const char *error() const;

    /// Mute/unmute a SID voice (0-2). Takes effect immediately while playing
    /// and is re-applied on the next open(); used to mirror the editor's
    /// per-channel mute onto the authentic playback.
    void setVoiceMuted(int voice, bool muted);

private:
    struct Impl;
    Impl *p;
};

} // namespace sidfp

#endif // SIDFP_PLAYER_H
