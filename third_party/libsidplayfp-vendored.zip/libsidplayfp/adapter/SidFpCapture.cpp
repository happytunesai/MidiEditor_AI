/*
 * SidFpCapture implementation - see SidFpCapture.h.
 *
 * Compiled INTO the sidplayfp static lib (so it has the lib's include dirs +
 * HAVE_CONFIG_H). Everything libsidplayfp-internal stays here; the app only
 * sees the plain-std SidFpCapture.h.
 */
#include "SidFpCapture.h"

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#include "sidplayfp/sidplayfp.h"
#include "sidplayfp/SidTune.h"
#include "sidplayfp/SidTuneInfo.h"
#include "sidplayfp/SidConfig.h"
#include "sidplayfp/sidbuilder.h"
#include "sidemu.h"
#include "sidlite/SID.h"

#include <cmath>
#include <new>

namespace {

using namespace libsidplayfp;

/**
 * A SID emulation that drives the bundled SIDLite chip (so the engine clocks
 * and advances exactly as on hardware) while recording every register write.
 * After each frame we read back the 32-byte register file for MIDI
 * reconstruction.
 */
class CaptureSidEmu final : public sidemu
{
    SIDLite::SID &m_sid;
    uint8_t       m_regs[32] = {0};

public:
    explicit CaptureSidEmu(sidbuilder *b)
        : sidemu(b), m_sid(*(new SIDLite::SID)) { reset(0); }
    ~CaptureSidEmu() override { delete &m_sid; delete[] m_buffer; }

    const uint8_t *regs() const { return m_regs; }

    uint8_t read(uint_least8_t addr) override { clock(); return static_cast<uint8_t>(m_sid.read(addr)); }

    void write(uint_least8_t addr, uint8_t data) override
    {
        clock();
        if (addr < 32) m_regs[addr] = data;
        m_sid.write(addr, data);
    }

    void reset(uint8_t volume) override
    {
        m_accessClk = 0;
        for (auto &r : m_regs) r = 0;
        m_sid.reset();
        m_sid.write(0x18, volume);
        m_regs[0x18] = volume;
    }

    void clock() override
    {
        const event_clock_t cycles =
            eventScheduler->getTime(EVENT_CLOCK_PHI1) - m_accessClk;
        m_accessClk += cycles;
        m_bufferpos += m_sid.clock(static_cast<unsigned int>(cycles), m_buffer + m_bufferpos);
    }

    void sampling(float systemclock, float freq, SidConfig::sampling_method_t) override
    {
        if (!m_sid.setSamplingParameters(static_cast<unsigned int>(systemclock),
                                         static_cast<unsigned short>(freq)))
        {
            m_status = false;
            m_error = ERR_UNSUPPORTED_FREQ;
        }
        delete[] m_buffer;
        // Generous 100 ms buffer so a whole video frame never overflows it.
        const int buffersize = static_cast<int>(std::ceil((freq / 1000.f) * 100.f));
        m_buffer = new short[buffersize];
        m_status = true;
    }

    void model(SidConfig::sid_model_t model, bool) override
    {
        m_sid.setChipModel(model == SidConfig::MOS8580
                               ? SIDLite::SID::model_t::MOS8580
                               : SIDLite::SID::model_t::MOS6581);
        m_status = true;
    }
};

/** Builder that hands the engine our capture SID and keeps a pointer to it. */
class CaptureSidBuilder final : public sidbuilder
{
    CaptureSidEmu *m_emu = nullptr;

public:
    CaptureSidBuilder() : sidbuilder("CaptureSID") {}

    CaptureSidEmu *emu() const { return m_emu; }

protected:
    libsidplayfp::sidemu *create() override
    {
        try { m_emu = new CaptureSidEmu(this); return m_emu; }
        catch (std::bad_alloc const &)
        {
            m_errorBuffer.assign(name()).append(" ERROR: out of memory");
            return nullptr;
        }
    }
    const char *getCredits() const override { return "Capture SID (MidiEditor)\n"; }
};

} // namespace

namespace sidfp {

CaptureResult captureSidRegisters(const uint8_t *data, std::size_t len,
                                  int song, int maxFrames,
                                  const std::function<void(int, int)> &onProgress)
{
    CaptureResult r;
    if (!data || len == 0) { r.error = "Empty SID data."; return r; }

    SidTune tune(reinterpret_cast<const uint_least8_t *>(data),
                 static_cast<uint_least32_t>(len));
    if (!tune.getStatus()) { r.error = tune.statusString(); return r; }
    tune.selectSong(song > 0 ? static_cast<unsigned int>(song) : 0);

    CaptureSidBuilder builder;
    sidplayfp engine;
    engine.setRoms(nullptr, nullptr, nullptr); // libsidplayfp runs ROM-free

    SidConfig cfg;
    cfg.frequency      = 44100;
    cfg.samplingMethod = SidConfig::INTERPOLATE;
    cfg.sidEmulation   = &builder;
    if (!engine.config(cfg)) { r.error = engine.error(); return r; }
    if (!engine.load(&tune)) { r.error = engine.error(); return r; }

    // Per-frame timing from the tune's clock.
    const SidTuneInfo *ti = tune.getInfo();
    r.ntsc = (ti && ti->clockSpeed() == SidTuneInfo::CLOCK_NTSC);
    r.clockHz         = r.ntsc ? 1022730.0 : 985248.0;
    r.framesPerSecond = r.ntsc ? 60.0 : 50.0;
    r.song            = (ti && ti->currentSong() > 0) ? ti->currentSong()
                                                      : (song > 0 ? song : 1);
    const unsigned int cyclesPerFrame =
        static_cast<unsigned int>(r.clockHz / r.framesPerSecond + 0.5);

    engine.initMixer(false); // mono; we discard the audio
    int bufN = engine.getBufSize(cyclesPerFrame);
    if (bufN < 1) bufN = 4096;
    std::vector<short> mixbuf(static_cast<std::size_t>(bufN));

    if (maxFrames < 1) maxFrames = 1;
    r.frames.reserve(static_cast<std::size_t>(maxFrames));

    for (int f = 0; f < maxFrames; ++f)
    {
        if (onProgress && (f & 0xFF) == 0) onProgress(f, maxFrames);
        const int produced = engine.play(cyclesPerFrame);
        if (produced < 0) { r.error = engine.error(); break; }
        if (produced > 0)
            engine.mix(mixbuf.data(), static_cast<unsigned int>(produced)); // drain + discard

        const CaptureSidEmu *e = builder.emu();
        if (!e) { r.error = "SID emulation was not created."; break; }
        std::array<uint8_t, 32> frame{};
        const uint8_t *regs = e->regs();
        for (int i = 0; i < 32; ++i) frame[i] = regs[i];
        r.frames.push_back(frame);
    }

    if (onProgress) onProgress(maxFrames, maxFrames);
    r.ok = !r.frames.empty();
    return r;
}

} // namespace sidfp
