/*
 * SidFpPlayer implementation - see SidFpPlayer.h. Compiled into sidplayfp.lib.
 */
#include "SidFpPlayer.h"

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#include "sidplayfp/sidplayfp.h"
#include "sidplayfp/SidTune.h"
#include "sidplayfp/SidConfig.h"
#include "builders/sidlite-builder/sidlite.h"
#include "sidemu.h" // libsidplayfp::sidemu::voice() for per-voice muting

#include <algorithm>
#include <cstring>
#include <vector>

namespace {
// SIDLiteBuilder that captures the sidemu it hands the engine, so we can mute
// individual voices (sidemu::voice() - the base masks the muted voice's gate).
class MuteableBuilder : public SIDLiteBuilder {
public:
    MuteableBuilder() : SIDLiteBuilder("MidiEditor") {}
    libsidplayfp::sidemu *emu() const { return _emu; }
protected:
    libsidplayfp::sidemu *create() override {
        _emu = SIDLiteBuilder::create();
        return _emu;
    }
private:
    libsidplayfp::sidemu *_emu = nullptr;
};
} // namespace

namespace sidfp {

struct Renderer::Impl {
    sidplayfp       engine;
    MuteableBuilder builder;
    SidTune        *tune = nullptr;
    uint8_t         muteMask = 0; // bit v set => voice v muted
    std::vector<short> chunk;     // mix scratch for one play() call
    std::vector<short> leftover;  // samples produced but not yet handed out
    std::size_t        leftoverPos = 0;
    int            cyclesPerCall = 0;
    bool           open = false;
    std::string    err = "N/A";

    ~Impl() { delete tune; }
};

Renderer::Renderer() : p(new Impl) {}
Renderer::~Renderer() { delete p; }

bool Renderer::open(const uint8_t *data, std::size_t len, int song, int sampleRate)
{
    p->open = false;
    if (!data || len == 0) { p->err = "Empty SID data."; return false; }
    if (sampleRate < 8000) sampleRate = 44100;

    delete p->tune;
    p->tune = new SidTune(reinterpret_cast<const uint_least8_t *>(data),
                          static_cast<uint_least32_t>(len));
    if (!p->tune->getStatus()) { p->err = p->tune->statusString(); return false; }
    p->tune->selectSong(song > 0 ? static_cast<unsigned int>(song) : 0);

    p->engine.setRoms(nullptr, nullptr, nullptr); // ROM-free

    SidConfig cfg;
    cfg.frequency      = static_cast<uint_least32_t>(sampleRate);
    cfg.samplingMethod = SidConfig::INTERPOLATE;
    cfg.sidEmulation   = &p->builder; // channel count comes from initMixer(false)
    if (!p->engine.config(cfg)) { p->err = p->engine.error(); return false; }
    if (!p->engine.load(p->tune)) { p->err = p->engine.error(); return false; }

    p->engine.initMixer(false); // mono
    // Render in ~one video-frame chunks (small, drains the SID's buffer safely).
    p->cyclesPerCall = 20000;
    int bufN = p->engine.getBufSize(static_cast<unsigned int>(p->cyclesPerCall));
    if (bufN < 1) bufN = 4096;
    p->chunk.assign(static_cast<std::size_t>(bufN), 0);
    p->leftover.clear();
    p->leftoverPos = 0;

    // The emu now exists (created during config/load) - apply any voice mutes.
    if (libsidplayfp::sidemu *e = p->builder.emu())
        for (int v = 0; v < 3; ++v)
            e->voice(static_cast<unsigned>(v), (p->muteMask >> v) & 1);

    p->open = true;
    p->err = "N/A";
    return true;
}

void Renderer::setVoiceMuted(int voice, bool muted) {
    if (voice < 0 || voice > 2) return;
    if (muted) p->muteMask |= static_cast<uint8_t>(1 << voice);
    else       p->muteMask &= static_cast<uint8_t>(~(1 << voice));
    if (libsidplayfp::sidemu *e = p->builder.emu())
        e->voice(static_cast<unsigned>(voice), muted);
}

int Renderer::render(short *out, int maxSamples)
{
    if (!p->open || !out || maxSamples <= 0) return 0;
    int written = 0;

    // 1) Hand out anything left over from the previous call first. Crucial for
    //    real-time pacing: the SID's mix() yields whole frames, so a request
    //    rarely lands on a frame boundary. Carrying the surplus forward (instead
    //    of discarding it) means no emulated SID-time is ever skipped - that
    //    skipping made playback run ~one frame too fast per call (cursor drift).
    if (p->leftoverPos < p->leftover.size()) {
        const int avail = static_cast<int>(p->leftover.size() - p->leftoverPos);
        const int take = std::min(avail, maxSamples);
        std::memcpy(out, p->leftover.data() + p->leftoverPos,
                    static_cast<std::size_t>(take) * sizeof(short));
        p->leftoverPos += static_cast<std::size_t>(take);
        written += take;
        if (p->leftoverPos >= p->leftover.size()) { p->leftover.clear(); p->leftoverPos = 0; }
    }

    // 2) Emulate more until the request is filled; stash any frame surplus.
    while (written < maxSamples)
    {
        const int produced = p->engine.play(static_cast<unsigned int>(p->cyclesPerCall));
        if (produced <= 0) break; // 0 or error: stop (caller pads with silence)
        const unsigned int got = p->engine.mix(p->chunk.data(),
                                               static_cast<unsigned int>(produced));
        if (got == 0) break;
        int n = static_cast<int>(got);
        if (n > maxSamples - written) n = maxSamples - written;
        std::memcpy(out + written, p->chunk.data(),
                    static_cast<std::size_t>(n) * sizeof(short));
        written += n;
        if (static_cast<unsigned int>(n) < got) { // keep the surplus for next call
            p->leftover.assign(p->chunk.begin() + n,
                               p->chunk.begin() + static_cast<int>(got));
            p->leftoverPos = 0;
        }
    }
    return written;
}

bool        Renderer::isOpen() const { return p->open; }
const char *Renderer::error()  const { return p->err.c_str(); }

} // namespace sidfp
