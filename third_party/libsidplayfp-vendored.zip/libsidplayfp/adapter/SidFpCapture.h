/*
 * SidFpCapture - thin adapter over libsidplayfp that runs a SID tune on the
 * cycle-accurate engine and snapshots the SID register file ($D400-$D41F) once
 * per video frame. The MidiEditor app links against this and never sees any
 * libsidplayfp internals (this header is plain std types only).
 *
 * Used to import RSID tunes (self-installed IRQ players) accurately, where the
 * from-scratch 6502 path produces noise. The captured per-frame register stream
 * feeds the existing sid::reconstructNotes() -> MIDI pipeline.
 */
#ifndef SIDFP_CAPTURE_H
#define SIDFP_CAPTURE_H

#include <array>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace sidfp {

struct CaptureResult {
    bool        ok = false;
    std::string error;
    bool        ntsc = false;
    double      clockHz = 0.0;          // C64 system clock (PAL/NTSC)
    double      framesPerSecond = 0.0;  // 50 (PAL) / 60 (NTSC)
    int         song = 0;               // 1-based song actually played
    std::vector<std::array<uint8_t, 32>> frames; // per-frame $D400..$D41F
};

/**
 * Run @p data (a one-file SID image, @p len bytes) on libsidplayfp's
 * cycle-accurate engine, capturing the SID registers once per video frame.
 *
 * @param song     1-based subtune to play, or 0 for the tune's default.
 * @param maxFrames how many frames to capture (frames are 50/60 Hz).
 * @param onProgress optional callback invoked periodically with
 *        (framesDone, totalFrames) so the caller can drive a progress bar.
 */
CaptureResult captureSidRegisters(const uint8_t *data, std::size_t len,
                                  int song, int maxFrames,
                                  const std::function<void(int, int)> &onProgress = {});

} // namespace sidfp

#endif // SIDFP_CAPTURE_H
