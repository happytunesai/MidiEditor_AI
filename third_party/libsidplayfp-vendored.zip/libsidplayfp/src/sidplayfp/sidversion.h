/* Generated from sidversion.h.in for the MSVC/CMake build (libsidplayfp 3.0.1). */
#ifndef LIBSIDPLAYFP_VERSION_H
#define LIBSIDPLAYFP_VERSION_H

#ifndef SIDPLAYFP_H
#  error Do not include directly.
#endif

#define LIBSIDPLAYFP_VERSION_MAJ 3
#define LIBSIDPLAYFP_VERSION_MIN 0
#define LIBSIDPLAYFP_VERSION_LEV 1

#endif
