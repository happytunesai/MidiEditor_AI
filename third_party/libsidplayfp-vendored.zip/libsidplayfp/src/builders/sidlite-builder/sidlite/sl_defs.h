/* Generated from sl_defs.h.in for the MSVC/CMake build. MSVC has no
   __builtin_expect, so HAVE_BUILTIN_EXPECT is 0 and LIKELY/UNLIKELY are no-ops. */
#ifndef SIDLITE_DEFS_H
#define SIDLITE_DEFS_H

#define HAVE_BUILTIN_EXPECT 0

#if HAVE_BUILTIN_EXPECT
#  define LIKELY(x)      __builtin_expect(!!(x), 1)
#  define UNLIKELY(x)    __builtin_expect(!!(x), 0)
#else
#  define LIKELY(x)      (x)
#  define UNLIKELY(x)    (x)
#endif

#endif // SIDLITE_DEFS_H
