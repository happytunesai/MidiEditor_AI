/*
 * Hand-written config.h for the MSVC / CMake build of libsidplayfp 3.0.1
 * (replaces the autotools-generated src/config.h - see src/config.h.in).
 * Only the symbols the vendored sources actually use are defined; all the
 * platform bits we don't have on Windows/MSVC (pthread, dlfcn, strings.h,
 * residfp/exsid/usbsid, soundcard, ...) are intentionally left undefined.
 */
#ifndef LIBSIDPLAYFP_MSVC_CONFIG_H
#define LIBSIDPLAYFP_MSVC_CONFIG_H

#define PACKAGE           "libsidplayfp"
#define PACKAGE_NAME      "libsidplayfp"
#define PACKAGE_TARNAME   "libsidplayfp"
#define PACKAGE_VERSION   "3.0.1"
#define PACKAGE_STRING    "libsidplayfp 3.0.1"
#define PACKAGE_URL       "https://github.com/libsidplayfp/libsidplayfp/"
#define PACKAGE_BUGREPORT ""
#define VERSION           "3.0.1"

/* We compile with /std:c++17; sidcxx11.h derives HAVE_CXX14/HAVE_CXX11 from
   this single define. Do NOT define HAVE_CXX20/23 (no [[likely]] in C++17). */
#define HAVE_CXX17 1

/* Standard C headers / fixed-width types are all available on MSVC. */
#define STDC_HEADERS  1
#define HAVE_STDINT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STDIO_H  1
#define HAVE_STRING_H 1
#define HAVE_INT8_T   1
#define HAVE_INT16_T  1
#define HAVE_INT32_T  1
#define HAVE_UINT8_T  1
#define HAVE_UINT16_T 1
#define HAVE_UINT32_T 1

/* x86/x64 is little-endian -> WORDS_BIGENDIAN intentionally undefined. */

#endif // LIBSIDPLAYFP_MSVC_CONFIG_H
