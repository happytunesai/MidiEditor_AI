libsidplayfp is a C64 music player library which integrates
the reSID and reSIDfp SID chip emulation into a cycle-based
emulator environment, constantly aiming to improve emulation
of the C64 system and the SID chips.

Copyright (c) 2000 Simon White
Copyright (c) 2007-2010 Antti Lankila
Copyright (c) 2010-2026 Leandro Nini

This version of the freely available libsidplayfp emulator engine source code
contains the following contributed or derived work. In the order they first
supplied contributions or code was derived from their work:

    Dag Lem           - reSID library
    Michael Schwendt  - initial implementation of SidTune library,
                        SidTune Wrapper, MD5 (based on work by L. Peter Deutsch)
    Simon White       - Majority of LIBSIDPLAY2 Code
    Antti Lankila     - SID distortion simulation (reSID-fp),
                        emulation improvements
    Leandro Nini      - build system rewrite, code refactoring,
                        backporting fixes from jsidplay2 and VICE,
                        emulation improvements
    LaLa              - stilview
    André Fachat      - reloc65
    Jarno Paananen    - HardSID UNIX builder
    Thibaut VARENE    - exSID driver and builder
    LouD              - USBSID-Pico driver and builder
    Mihály Horváth    - crSID, base of the sidlite engine

VIC II, CIA and cpu-port emulation is based on VICE code.
CIA SDR and interrupt handling are based on Denise emulator
implementation.

COMPUTE!'s Sidplayer by Craig Chamberlain and Harry Bratt.

Credit where credit is due, so if I missed anyone please let me know.

-----------------------------------------------------------------------------

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

